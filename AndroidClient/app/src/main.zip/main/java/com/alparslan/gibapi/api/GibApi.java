package com.alparslan.gibapi.api;

import com.alparslan.gibapi.dto.FullProcessRequest;
import com.alparslan.gibapi.dto.FullProcessResponse;
import com.alparslan.gibapi.dto.LogoutRequest;
import com.alparslan.gibapi.dto.SessionRequest;
import com.alparslan.gibapi.dto.SessionResponse;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface GibApi {

    @POST("/api/v1/session")
    Call<SessionResponse> createSession(@Body SessionRequest body);

    @POST("/api/v1/full-process")
    Call<FullProcessResponse> createInvoice(@Body FullProcessRequest body);

    @POST("/api/v1/logout")
    Call<Void> logout(@Body LogoutRequest body);

    @POST("/api/v1/session/force")
    Call<SessionResponse> forceSession(@Body SessionRequest body);

    // GET /api/v1/download-pdf/{fatura_uuid}?session_id=...
    @GET("/api/v1/download-pdf/{fatura_uuid}")
    Call<ResponseBody> downloadPdf(
            @Path("fatura_uuid") String faturaUuid,
            @Query("session_id") String sessionId
    );

}
