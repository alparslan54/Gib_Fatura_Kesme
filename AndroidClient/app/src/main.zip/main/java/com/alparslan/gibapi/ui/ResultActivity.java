package com.alparslan.gibapi.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.alparslan.gibapi.R;
import com.alparslan.gibapi.api.ApiClient;
import com.alparslan.gibapi.api.GibApi;
import com.alparslan.gibapi.core.SessionManager;
import com.alparslan.gibapi.dto.LogoutRequest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_result);
        SessionManager.init(getApplicationContext());


        String uuid = getIntent().getStringExtra("uuid");
        String status = getIntent().getStringExtra("status");
        String smsErr = getIntent().getStringExtra("sms_error");

        TextView tvStatus = findViewById(R.id.tvstatus);
        TextView tvUuid = findViewById(R.id.tvuuid);
        TextView tvSms = findViewById(R.id.tvsms);
        Button btnLogout = findViewById(R.id.btn_logout);
        Button btnDownloadPdf = findViewById(R.id.btn_download_pdf);

        tvStatus.setText("Durum: " + (status == null ? "-" : status));
        tvUuid.setText("UUID: " + (uuid == null ? "-" : uuid));
        tvSms.setText("SMS: " + (smsErr == null || smsErr.isEmpty() ? "-" : ("Hata: " + smsErr)));

        // UUID yoksa PDF butonu kapalı
        if (uuid == null || uuid.trim().isEmpty()) {
            btnDownloadPdf.setEnabled(false);
        }

        btnDownloadPdf.setOnClickListener(v -> downloadAndOpenPdf(uuid));

        btnLogout.setOnClickListener(v -> {
            String baseUrl = getIntent().getStringExtra("baseUrl");
            if (baseUrl == null || baseUrl.trim().isEmpty()) {
                baseUrl = SessionManager.getBaseUrl();
            }
            if (baseUrl == null) baseUrl = "";
            if (!baseUrl.endsWith("/")) baseUrl += "/";


            String sid = SessionManager.get();

            // 1) BACKEND LOGOUT ÇAĞRISI
            if (sid != null && !sid.isEmpty()) {
                GibApi api = ApiClient.create(baseUrl);
                api.logout(new LogoutRequest(sid)).enqueue(new retrofit2.Callback<Void>() {
                    @Override
                    public void onResponse(retrofit2.Call<Void> call, retrofit2.Response<Void> response) {
                        Log.i("GIBAPI", "Backend logout OK " + response.code());
                    }

                    @Override
                    public void onFailure(retrofit2.Call<Void> call, Throwable t) {
                        Log.e("GIBAPI", "Backend logout FAIL: " + t.getMessage());
                    }
                });
            }

            // 2) LOCAL SESSION SİL
            SessionManager.clearAll();


            // 3) LOGIN’E DÖN
            Intent i = new Intent(ResultActivity.this, LoginActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        });
    }

    private void downloadAndOpenPdf(String uuid) {
        String baseUrl = getIntent().getStringExtra("baseUrl");
        if (baseUrl == null) baseUrl = "";
        if (!baseUrl.endsWith("/")) baseUrl += "/";

        String sid = SessionManager.get();
        if (sid == null || sid.isEmpty()) {
            Toast.makeText(this, "Session yok. Tekrar giriş yap.", Toast.LENGTH_LONG).show();
            return;
        }
        if (uuid == null || uuid.trim().isEmpty()) {
            Toast.makeText(this, "UUID yok.", Toast.LENGTH_LONG).show();
            return;
        }

        Toast.makeText(this, "PDF indiriliyor...", Toast.LENGTH_SHORT).show();

        GibApi api = ApiClient.create(baseUrl);
        api.downloadPdf(uuid, sid).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> res) {
                if (!res.isSuccessful() || res.body() == null) {
                    Toast.makeText(ResultActivity.this,
                            "PDF indirilemedi: HTTP " + res.code(),
                            Toast.LENGTH_LONG).show();
                    return;
                }

                try {
                    File pdf = savePdfToAppDownloads(res.body(), "fatura-" + uuid + ".pdf");
                    openPdf(pdf);
                } catch (Exception e) {
                    Log.e("GIBAPI", "PDF save/open error", e);
                    Toast.makeText(ResultActivity.this,
                            "PDF kaydetme hatası: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(ResultActivity.this,
                        "PDF indirme hatası: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private File savePdfToAppDownloads(ResponseBody body, String filename) throws Exception {
        // /Android/data/<package>/files/Download/
        File dir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = getFilesDir();
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Klasör oluşturulamadı: " + dir);

        File outFile = new File(dir, filename);

        try (InputStream in = body.byteStream();
             FileOutputStream out = new FileOutputStream(outFile)) {
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) != -1) out.write(buf, 0, r);
            out.flush();
        }
        return outFile;
    }

    private void openPdf(File file) {
        Uri uri = FileProvider.getUriForFile(
                this,
                getPackageName() + ".fileprovider",
                file
        );

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this,
                    "PDF açacak uygulama bulunamadı. Dosya: " + file.getAbsolutePath(),
                    Toast.LENGTH_LONG).show();
        }
    }
}
