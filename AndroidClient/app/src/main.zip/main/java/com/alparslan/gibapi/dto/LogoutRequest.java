// com.alparslan.gibapi.dto.LogoutRequest
package com.alparslan.gibapi.dto;

public class LogoutRequest {
    public String session_id;

    public LogoutRequest(String sid) {
        this.session_id = sid;
    }
}
