package com.alparslan.gibapi.api;



import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class ApiClient {

    private static volatile OkHttpClient client;
    private static final Map<String, Retrofit> RETROFITS = new ConcurrentHashMap<>();

    private ApiClient() {}

    public static GibApi create(String baseUrl) {
        String normalized = normalizeBaseUrl(baseUrl);
        Retrofit r = RETROFITS.get(normalized);
        if (r == null) {
            // Double-check + putIfAbsent pattern
            Retrofit newRetrofit = new Retrofit.Builder()
                    .baseUrl(normalized)
                    .client(getClient())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            Retrofit existing = RETROFITS.putIfAbsent(normalized, newRetrofit);
            r = (existing != null) ? existing : newRetrofit;
        }
        return r.create(GibApi.class);
    }

    private static OkHttpClient getClient() {
        if (client == null) {
            synchronized (ApiClient.class) {
                if (client == null) {
                    OkHttpClient.Builder b = new OkHttpClient.Builder()
                            .connectTimeout(15, TimeUnit.SECONDS)
                            .readTimeout(60, TimeUnit.SECONDS)
                            .writeTimeout(60, TimeUnit.SECONDS)
                            .retryOnConnectionFailure(true);

                    // DEBUG'da detaylı log; Release'te kapalı
                    HttpLoggingInterceptor log = new HttpLoggingInterceptor();
                    log.setLevel(HttpLoggingInterceptor.Level.BASIC);
                    b.addInterceptor(log);


                    client = b.build();
                }
            }
        }
        return client;
    }

    public static String normalizeBaseUrl(String input) {
        if (input == null) return "http://127.0.0.1:8000/";
        String s = input.trim();
        if (s.isEmpty()) return "http://127.0.0.1:8000/";

        // Kullanıcı "127.0.0.1:8000" yazarsa otomatik http ekle
        if (!s.startsWith("http://") && !s.startsWith("https://")) {
            s = "http://" + s;
        }

        if (!s.endsWith("/")) s = s + "/";
        return s;
    }
}
